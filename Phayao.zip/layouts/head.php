<!-- This is the universal head in all the pages -->
<!DOCTYPE html>
<html>
<head>
	<title>Phayao / Inicio</title>
	<meta charset="UTF-8"/>

	<!-- No cache -->
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="0" />

	<link rel="stylesheet" type="text/css" href="styles/universal.css">
	<link rel="stylesheet" type="text/css" href="styles/header.css">
	<link rel="stylesheet" type="text/css" href="styles/footer.css">
	<link rel="icon" href="media/logo.png">