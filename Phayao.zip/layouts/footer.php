<!-- This is the universal footer in all the pages -->
<footer>
	<div id="footer-izq">
		<div id="footer-ubicacion">
			<img src="media/icons/ubicacion.png" id="img-ubicacion">
			<h3>Ubicación:</h3>
		</div>
		<p>C. Quinta 55, Las Fuentes, 88740 Reynosa, Tamps.</p>
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d766.4591398844542!2d-98.31498679645887!3d26.07249959342053!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x866505f0bbb9722d%3A0xc32262173daecab9!2sC.%20Quinta%2055%2C%20Las%20Fuentes%2C%2088740%20Reynosa%2C%20Tamps.!5e1!3m2!1ses!2smx!4v1654267606791!5m2!1ses!2smx" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" id="mapa"></iframe>
	</div>

	<div id="footer-der">
		<h3>Contacto:</h3>
		<div id="footer-telefono">
			<img src="media/icons/telefono.png" id="img-tel">
			<p>Tel. 8991127589</p>
		</div>
		<div id="footer-email">
			<img src="media/icons/email.png" id="img-email">
			<p>E-mail: contacto@phayao.com</p>
		</div>
		<br>
		<h3>Enlaces:</h3>
		<div id="footer-inicio">
			<img src="media/icons/casa.png" id="img-casa">
			<a href="index.php" id="footer-inicio">Inicio</a>
		</div>
		<div id="footer-menu">
			<img src="media/icons/menu.png" id="img-menu">
			<a href="menu.php" id="footer-menu">Menú</a>
		</div>
		<div id="footer-reservaciones">
			<img src="media/icons/reservaciones.png" id="img-reservaciones">
			<a href="reservaciones.php" id="footer-reservaciones">Reservaciones</a>
		</div>
		<div id="footer-contacto">
			<img src="media/icons/contacto.png" id="img-contactanos">
			<a href="contactanos.php" id="footer-contactanos">Contáctanos</a>
		</div>
		<p id="cc">Sitio desarrollado por: Izak Cancino</p>
	</div>
</footer>

<!-- Scripts -->
<script src="js/btn-to-top.js"></script>