<?php 
    include("layouts/head.php"); 
?>
<?php 
    include("layouts/header.php"); 
?>

    <!-- TODO: "Contáctanos" page -->

<?php 
    include("layouts/footer.php"); 
?>

</body>
</html>