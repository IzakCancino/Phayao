<?php 
    include("layouts/head.php"); 
?>
<?php 
    include("layouts/header.php"); 
?>

    <!-- TODO: "Reservaciones" page -->

<?php 
    include("layouts/footer.php");
?>

</body>
</html>